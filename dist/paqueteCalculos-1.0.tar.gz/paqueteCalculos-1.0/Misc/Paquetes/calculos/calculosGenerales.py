def sumar(numero1, numero2) :
    print ("La suma es: " + str(numero1 + numero2))

def restar(numero1, numero2) :
    print ("La resta es: " + str(numero1 - numero2))

def multiplicar(numero1, numero2) :
    print ("La multiplicacion es: " + str(numero1 * numero2))

def dividir(numero1, numero2) :
    print ("La suma es: " + str(numero1 / numero2))

def potencia(numero1, numero2) :
    print ("La potencia es: " + str(numero1 ** numero2))

def redondear(numero1) :
    print ("Redondeado: " + str(round(numero1)))