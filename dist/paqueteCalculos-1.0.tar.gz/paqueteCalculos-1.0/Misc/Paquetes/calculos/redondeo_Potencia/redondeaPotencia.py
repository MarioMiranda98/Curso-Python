def potencia(numero1, numero2) :
    print ("La potencia es: " + str(numero1 ** numero2))

def redondear(numero1) :
    print ("Redondeado: " + str(round(numero1)))